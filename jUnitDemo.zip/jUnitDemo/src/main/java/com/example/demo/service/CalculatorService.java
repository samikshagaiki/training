package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class CalculatorService {
	public int add(int a , int b) {
		return a+b;
	}
	
	public int subtraction(int a , int b) {
		return a-b;
	}
	
	public int multiply(int a , int b) {
		return a*b;
	}
	
	public int divide(int a , int b) {
		return a/b;
	}
	
	
}

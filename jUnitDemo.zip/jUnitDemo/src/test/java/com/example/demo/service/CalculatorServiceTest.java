package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class CalculatorServiceTest {
	CalculatorService service = new CalculatorService();
	
	@Test
	void testadd() {
		int result = service.add(10, 20);
		assertEquals(30, result);
	}
	
	@Test
	void testsub() {
		int result1 = service.subtraction(20, 10);
		assertEquals(10, result1);
	}
	
	@Test
	void testdiv() {
		int result2 = service.divide(20, 10);
		assertEquals(2, result2);
	}
	
	@Test
	void testDivide() {
		assertThrows(ArithmeticException.class,()->{
			service.divide(10,0);
		});
	}
	
	@Test
	void testPositiveResult() {
		int result4 = service.add(5, 5);
		assertTrue(result4>0);
	}
	
	@Test 
	void testNegetiveResult() {
		int result5 = service.add(5,5);
		assertFalse(result5<0);
	}
}

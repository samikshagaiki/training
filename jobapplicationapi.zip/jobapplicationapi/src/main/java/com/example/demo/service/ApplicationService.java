package com.example.demo.service;


import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.ApplicationRequest;
import com.example.demo.model.Application;
import com.example.demo.model.Job;
import com.example.demo.repository.ApplicationRepository;
import com.example.demo.repository.JobRepository;

@Service
public class ApplicationService {

    @Autowired
    ApplicationRepository appRepo;

    @Autowired
    JobRepository jobRepo;

    public String apply(
            ApplicationRequest req) {

        Job job = jobRepo.findById(req.getJobId())

                .orElseThrow(() ->
                        new RuntimeException(
                                "Job Not Found"));

        boolean exists =
                appRepo.existsByStudentIdAndJobId(
                        req.getStudentId(),
                        req.getJobId());

        if(exists) {
            throw new RuntimeException(
                    "Already Applied");
        }

        Application app =
                new Application();

        app.setStudentId(
                req.getStudentId());

        app.setApplicationDate(
                LocalDate.now().toString());

        app.setStatus("APPLIED");

        app.setJob(job);

        appRepo.save(app);

        return "Applied Successfully";
    }

    public List<Application> getAll() {
        return appRepo.findAll();
    }
}

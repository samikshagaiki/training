package com.example.demo.model;

import java.util.List;

import jakarta.persistence.*;

@Entity
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String companyName;

    private String role;

    private double packageAmount;

    private String location;

    @OneToMany(mappedBy = "job",cascade = CascadeType.ALL)

    private List<Application> applications;

    public Job() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public double getPackageAmount() {
        return packageAmount;
    }

    public void setPackageAmount(double packageAmount) {
        this.packageAmount = packageAmount;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public List<Application> getApplications() {
        return applications;
    }

   

	public void setApplications(
            List<Application> applications) {

        this.applications = applications;
    }
	
	 @Override
		public String toString() {
			return "Job [id=" + id + ", companyName=" + companyName + ", role=" + role + ", packageAmount=" + packageAmount
					+ ", location=" + location + ", applications=" + applications + "]";
		}
    
    
}

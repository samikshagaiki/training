package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.ApplicationRequest;
import com.example.demo.model.Application;
import com.example.demo.service.ApplicationService;

@RestController
@RequestMapping("/applications")
public class ApplicationController {

    @Autowired
    ApplicationService service;

    @PostMapping("/apply")
    public String apply(
            @RequestBody ApplicationRequest req) {

        return service.apply(req);
    }

    @GetMapping
    public List<Application> getAll() {

        return service.getAll();
    }
}

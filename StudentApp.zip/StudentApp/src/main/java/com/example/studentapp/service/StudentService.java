package com.example.studentapp.service;

import org.springframework.stereotype.Service;

@Service
public class StudentService {
	public int addMarks(int A,int B) {
		return A+B;
	}
	
	public float divideMarks(int A,int B) {
		return A/B;
	}
}

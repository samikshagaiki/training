package com.example.studentapp.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {

    // API 1
    @GetMapping("/welcome")
    public String welcome() {
        return "Welcome Students";
    }

    // API 2
    @GetMapping("/test")
    public String test() {
        return "Spring Boot Testing";
    }
}
package com.example.studentapp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class StudentServiceTest {

    StudentService service = new StudentService();

    // Test addMarks()
    @Test
    public void testAddMarks() {

        int result = service.addMarks(40, 50);

        assertEquals(90, result);
    }

    // Test divideMarks()
    @Test
    public void testDivideMarks() {

        float result = service.divideMarks(100, 2);

        assertEquals(50, result);
    }
}
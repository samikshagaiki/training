package com.example.studentapp.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class StudentControllerTest {

    StudentController controller = new StudentController();

    // Test welcome API
    @Test
    public void testWelcome() {

        String result = controller.welcome();

        assertEquals("Welcome Students", result);
    }

    // Test test API
    @Test
    public void testTest() {

        String result = controller.test();

        assertEquals("Spring Boot Testing", result);
    }
}
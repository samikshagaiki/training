package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="students")
public class Student{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@NotNull
	@Size(min = 3, message = "Student name must have at least 3 characters")
	private String name;
	
	@Email(message = "Please enter valid email")
	@NotBlank(message = "Email cannot be blank")
	private String email;
	
	@NotBlank(message = "Branch cannot be blank")
	private String branch;
	
	@NotNull
	@DecimalMin(value = "0.0", message = "CGPA must be >= 0")
	@DecimalMax(value = "10.0", message = "CGPA must be <= 10")
	private Float cgpa;
	
	
	
	public Student() {
		
	}



	public Student(@NotNull @Size(min = 3, message = "Student name must have at least 3 characters") String name,
			@Email(message = "Please enter valid email") @NotBlank(message = "Email cannot be blank") String email,
			@NotBlank(message = "Branch cannot be blank") String branch,
			@NotNull @DecimalMin(value = "0.0", message = "CGPA must be >= 0") @DecimalMax(value = "10.0", message = "CGPA must be <= 10") Float cgpa) {
		super();
		this.name = name;
		this.email = email;
		this.branch = branch;
		this.cgpa = cgpa;
	}







	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getBranch() {
		return branch;
	}



	public void setBranch(String branch) {
		this.branch = branch;
	}



	public float getCgpa() {
		return cgpa;
	}



	public void setCgpa(float cgpa) {
		this.cgpa = cgpa;
	}



	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", email=" + email + ", branch=" + branch + ", cgpa=" + cgpa
				+ "]";
	}

	
}
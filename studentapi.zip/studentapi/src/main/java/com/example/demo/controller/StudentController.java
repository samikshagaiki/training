package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

import jakarta.validation.Valid;


@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = "http://localhost:3000")
public class StudentController {

    @Autowired
    private StudentService service;

  

    @PostMapping("/add")
    public Student addStudent(@Valid @RequestBody Student student) {
        return service.save(student);
    }

    

    @GetMapping("/all")
    public List<Student> findAllStudents() {
        return service.getAll();
    }

   

    @GetMapping("/students/{id}")
    public Student findStudentId(@PathVariable int id) {
        return service.getById(id);
    }
    
    @GetMapping("/branch/{branch}")
    public List<Student> findBranch(@PathVariable String branch) {
        return service.getByBranch(branch);
    }

  

    @DeleteMapping("/students/{id}")
    public String deleteCustomer(@PathVariable int id) {
        return service.delete(id);
    }
    
}




/* Endpoints
Method		Endpoint					Purpose
POST		/api/v1/products/add		Add Product
GET			/api/v1/products/all		Get All Products
GET			/api/v1/products/find/1		Get Product By ID
PUT			/api/v1/products/update		Update Product
DELETE		/api/v1/products/delete/1	Delete Product
 */

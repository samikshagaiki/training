package com.example.demo.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;



@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository repository;

    @Override
    public Student save(Student obj) {
        return repository.save(obj);
    }

    @Override
    public List<Student> getAll() {
        return repository.findAll();
    }

    @Override
    public Student getById(int id) {
        return repository.findById(id).orElse(null);
    }
    
    @Override
    public List<Student> getByBranch(String branch) {
        return repository.findByBranch(branch);
    }


    @Override
    public String delete(int id) {
        repository.deleteById(id);
        return "Deleted Successfully";
    }
}






package com.example.demo.service;


import java.util.List;

import com.example.demo.model.Student;


public interface StudentService {

    Student save(Student obj);

    List<Student> getAll();

    Student getById(int id);


    String delete(int id);

	List<Student> getByBranch(String branch);
}


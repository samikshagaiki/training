package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class HelloControllerTest {
	HelloController controller = new HelloController();
	
	void testHello() {
		String result = controller.hello();
		
		assertEquals("Hello Students",result);
	}
}
